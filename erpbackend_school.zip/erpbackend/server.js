import express from 'express';
import dotenv from 'dotenv';
import morgan from 'morgan';
import connectDb from './db.js';
import cors from 'cors';


import wsServer from './ws';
dotenv.config();



import userRoutes from './routes/userRoutes.js';

connectDb();
const app = express();

app.use(express.json());

app.use(morgan('dev'));
app.use(cors());

app.use('/api/', userRoutes);

//Whenever someone connects this gets executed

app.get('/', (req, res) => {
  res.json({ message: 'Hello World' });
});

const PORT = process.env.PORT;



app.listen(PORT, () => {
  console.log("Listening on port: " + PORT);
});


