import User from '../models/userModel.js';
import asyncHandler from 'express-async-handler';
import generateToken from '../utils/generateToken.js';
import qs from 'qs';
import axios from 'axios';

//@desc     Auth User & Get Token
//@route    POST api/users/login
//@access   Public

const login = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const passwordone=req.body.password;
  const user = await User.findOne({ email });      
  const password ='admin123'
 

  if (user && (await user.matchPassword(password))) {
  
   var auth=await getData(email,passwordone)
    .then(res => {return res;})
console.log(auth)
    if(auth){
  
return res.json({
  _id: user._id,
  name: user.name,
  email: user.email,
  isAdmin: user.isAdmin,
  token: generateToken(user._id),
});
}
else{
  res.status(401);
  throw new Error('Contact Administrator');
}
}

else {
  res.status(401).json({
    message:'Contact Admin'
  });
 
}
});

//@desc     REGISTER User & Get Token
//@route    POST api/users/register
//@access   Public
const register = asyncHandler(async (req, res) => {
  const {index,email,short_code,employee_code,biometric_code,
         designation,role,nature_of_appointment,date_of_appointment,
         department,status,first_name,middle_name,last_name,dob,gender} = req.body;
  const password='admin123'
  const mobile='';
  const created_at=new Date();
  const userExist = await User.findOne({ email });

  if (userExist) {
    res.status(400);
    throw new Error('User already Exist');
  }

  const user = await User.create({index,email,short_code,employee_code,biometric_code,
    designation,role,nature_of_appointment,date_of_appointment,
    department,status,first_name,middle_name,last_name,dob,gender, password,mobile,created_at });

  if (user) {
    res.status(201).json({
      _id: user._id,
   
      role:'',
      email: user.email,
      isAdmin: user.isAdmin,
      token: generateToken(user._id),
    });
  } else {
    res.status(400);
    throw new Error('Invalid User Data');
  }
});


async function getData(email,passwordone) {
  
    var data = qs.stringify({
      'client_id': '769c2992-a18f-4c27-af47-e8884074fd17',
      'scope': 'user.read openid profile offline_access',
      'client_secret': '6Fl7Q~ewbjfMPzlJ1HPehq67B5.aaq3puLhEw',
      'username': email,
      'password': passwordone,
      'grant_type': 'password' 
    });
    
    return await axios.post('https://login.microsoftonline.com/organizations/oauth2/v2.0/token', data,{
          headers: {
            'content-type': 'application/x-www-form-urlencoded'
          }
        }).then(response => {
     
     return true;
    
   
  },err=>{
   
    console.log('abhay22')
    return false;
  });
    
      // Don't forget to return something   

}

//@desc     Get all Users
//@route    GET api/users
//@access   Private/Admin
const getUsers = asyncHandler(async (req, res) => {
  const users = await User.find({});
  console.log(users)
  res.json(users);
});

//@desc     Update User Profile
//@route    PUT api/users/profile/:id
//@access   Private
const updateUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findOne({employee_code:req.body.employee_code});
  console.log(user)
  const data=req.body;
  if (user) {
   user.first_name=data.first_name;
   user.email=data.email;
   user.biometric_code= data.biometric_code;
   user.department=data.department;
   user.designation=data.designation;
   user.dob=data.dob;
   user.email=data.email;
   user.employee_code=data.employee_code;
   user.gender=data.gender;
   user.isAdmin=data.isAdmin;
   user.last_name=data.last_name;
   user.middle_name=data.middle_name;
   user.role=data.role;
   user.short_code=data.short_code;
   user.status=data.status;
  

    const updatedUser = await user.save();
    return res.json({
      _id: updatedUser._id,
      name:data.first_name+data.middle_name+data.last_name,
      isAdmin: updatedUser.isAdmin,
      token: generateToken(updatedUser._id),
    });
  } else {

    const {index,email,short_code,employee_code,biometric_code,
      designation,role,nature_of_appointment,date_of_appointment,
      department,status,first_name,middle_name,last_name,dob,gender} = req.body;
  const password='admin123'
  const mobile='';
  const created_at=new Date();
  const userExist = await User.findOne({ email });
  
  if (userExist) {
  res.status(400);
  throw new Error('User already Exist');
  }
  
  const user = await User.create({index,email,short_code,employee_code,biometric_code,
  designation,role,nature_of_appointment,date_of_appointment,
  department,status,first_name,middle_name,last_name,dob,gender, password,mobile,created_at });
  
  if (user) {
  res.status(201).json({
   _id: user._id,
  
   role:'',
   email: user.email,
   isAdmin: user.isAdmin,
   token: generateToken(user._id),
  });
  } else {
  res.status(400);
  throw new Error('Invalid User Data');
  }
  }
});


export { login, register, getUsers, updateUserProfile };
